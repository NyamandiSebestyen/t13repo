import { Component } from '@angular/core';

@Component({
  selector: 'app-halmazalapot',
  templateUrl: './halmazalapot.component.html',
  styleUrl: './halmazalapot.component.css'
})
export class HalmazalapotComponent {
  homerseklet:number = 0
  
  kep:string = "assets/img/ice.jpg"

  

   homersekletValtozas ():void {
    this.homerseklet <= 0? this.kep = "assets/img/ice.jpg":this.homerseklet > 0&&this.homerseklet < 100?this.kep = "assets/img/water.jpg":this.kep = "assets/img/steam.jpg"
    this.kep=="assets/img/ice.jpg"?this.hatterSzinezes("white"):this.kep=="assets/img/water.jpg"?this.hatterSzinezes("#91BBEB"):this.hatterSzinezes("black")
    this.kep=="assets/img/ice.jpg"?this.betuSzinezes("blue"):this.kep=="assets/img/water.jpg"?this.betuSzinezes("black"):this.betuSzinezes("red")
  }

  hatterSzinezes(szin: string): void {
    document.body.style.backgroundColor = szin;
  }

  betuSzinezes(szin:string):void{
    var p:HTMLParagraphElement|null = document.querySelector("p");
    p==null?console.error("nincs paragraph elem"):p.style.color = szin;
  }

}

