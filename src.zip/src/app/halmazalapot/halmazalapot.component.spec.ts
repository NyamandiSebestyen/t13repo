import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HalmazalapotComponent } from './halmazalapot.component';

describe('HalmazalapotComponent', () => {
  let component: HalmazalapotComponent;
  let fixture: ComponentFixture<HalmazalapotComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HalmazalapotComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HalmazalapotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
