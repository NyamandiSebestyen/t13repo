import { Component } from '@angular/core';

@Component({
  selector: 'app-kezdolap',
  templateUrl: './kezdolap.component.html',
  styleUrl: './kezdolap.component.css'
})
export class KezdolapComponent {

}
