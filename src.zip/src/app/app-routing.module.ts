import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SzavazatTablazatComponent } from './szavazat-tablazat/szavazat-tablazat.component';
import { Hiba404Component } from './hiba404/hiba404.component';

const routes: Routes = [
  {path:"szavazat-tablazat",component:SzavazatTablazatComponent},
  {path:"",redirectTo:"/szavazat-tablazat",pathMatch:"full"},
  {path:"**",component:Hiba404Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
