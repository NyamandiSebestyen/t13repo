import { Component } from '@angular/core';
import { tick } from '@angular/core/testing';

@Component({
  selector: 'app-parosparatlan',
  templateUrl: './parosparatlan.component.html',
  styleUrl: './parosparatlan.component.css'
})
export class ParosparatlanComponent {
  bemenetiSzam:number = 1
  kimenetiSzoveg:string = this.parosParatlan(this.bemenetiSzam);

  parosParatlan(szam:number):string{
    return szam%2==0?"Páros":"Páratlan";
  }

  valtozas():void {
    this.bemenetiSzam<0?this.kimenetiSzoveg="Hibás bemenet":
    this.bemenetiSzam==0?this.kimenetiSzoveg="Nulla":
      this.kimenetiSzoveg = this.parosParatlan(this.bemenetiSzam);
    }
}




