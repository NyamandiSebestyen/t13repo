import { Component } from '@angular/core';

@Component({
  selector: 'app-hiba404',
  templateUrl: './hiba404.component.html',
  styleUrl: './hiba404.component.css'
})
export class Hiba404Component {

}
