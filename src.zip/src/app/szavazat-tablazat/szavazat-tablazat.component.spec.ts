import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SzavazatTablazatComponent } from './szavazat-tablazat.component';

describe('SzavazatTablazatComponent', () => {
  let component: SzavazatTablazatComponent;
  let fixture: ComponentFixture<SzavazatTablazatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SzavazatTablazatComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SzavazatTablazatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
