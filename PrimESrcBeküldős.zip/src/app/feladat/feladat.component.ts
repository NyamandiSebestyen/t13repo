import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {

  szam: number = 1;
  mentettErtekek: string[] = [];
  primE(): string {
    let counter: number = 0;
    for (let i: number = 1; i < this.szam; i++) {

      if (this.szam % i == 0) {
        counter++;
      }
    }
    return counter > 1 || this.szam == 1 ? "NEM prím" : "prím";
  }

  EredmenyMentes(): void {
    this.mentettErtekek.push(`Az ${this.szam}: ${this.primE()}`);
  }

}
